from django.apps import AppConfig


class MyQuizConfig(AppConfig):
    name = 'my_quiz'
