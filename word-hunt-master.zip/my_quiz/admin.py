from django.contrib import admin
from .models import *


admin.site.register(QuestionandAnswer)
#admin.site.register(Answer)
#admin.site.register(Question)
